import { Button } from '@/components/ui/button';

const PricingSection = () => {
  const plans = [
    {
      name: 'Starter',
      price: '$29',
      description: 'Perfect for individuals and small businesses',
      features: [
        '100 keyword searches per day',
        'Basic metrics and suggestions',
        'CSV export capability',
        'Search history (30 days)',
      ],
      notIncluded: [
        'Advanced filtering options',
        'Competitor analysis',
      ],
      popular: false,
      borderClass: 'border border-gray-100',
    },
    {
      name: 'Professional',
      price: '$79',
      description: 'Ideal for marketing teams and agencies',
      features: [
        '500 keyword searches per day',
        'All metrics and advanced suggestions',
        'CSV and API export options',
        'Search history (90 days)',
        'Advanced filtering options',
      ],
      notIncluded: [
        'Competitor analysis',
      ],
      popular: true,
      borderClass: 'border-2 border-primary',
    },
    {
      name: 'Enterprise',
      price: '$199',
      description: 'For large businesses with advanced needs',
      features: [
        'Unlimited keyword searches',
        'All metrics and premium suggestions',
        'All export options with bulk capabilities',
        'Unlimited search history',
        'Advanced filtering and custom views',
        'Comprehensive competitor analysis',
      ],
      notIncluded: [],
      popular: false,
      borderClass: 'border border-gray-100',
    },
  ];

  const scrollToWaitlist = () => {
    document.getElementById('waitlist-form')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-16 bg-gray-50" id="pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base font-semibold tracking-wide uppercase text-primary">Pricing</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Simple, Transparent Pricing
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Choose the plan that's right for your needs. Special launch pricing available for early adopters.
          </p>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-3">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-lg shadow-lg overflow-hidden relative ${plan.borderClass}`}
            >
              {plan.popular && (
                <div className="absolute top-0 inset-x-0">
                  <div className="bg-primary text-center py-1 px-4 text-xs font-medium text-white uppercase tracking-wider">
                    Most Popular
                  </div>
                </div>
              )}
              <div className="px-6 py-8 bg-gray-50 border-b border-gray-100">
                <div className="text-center">
                  <h3 className="text-2xl font-medium text-gray-900">{plan.name}</h3>
                  <div className="mt-4 flex items-center justify-center">
                    <span className="text-5xl font-extrabold text-gray-900">{plan.price}</span>
                    <span className="ml-1 text-xl font-medium text-gray-500">/mo</span>
                  </div>
                  <p className="mt-4 text-sm text-gray-500">{plan.description}</p>
                </div>
              </div>
              <div className="px-6 py-8">
                <ul className="space-y-4">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <div className="flex-shrink-0">
                        <i className="fas fa-check text-secondary"></i>
                      </div>
                      <p className="ml-3 text-base text-gray-700">{feature}</p>
                    </li>
                  ))}
                  {plan.notIncluded.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <div className="flex-shrink-0">
                        <i className="fas fa-times text-gray-400"></i>
                      </div>
                      <p className="ml-3 text-base text-gray-500">{feature}</p>
                    </li>
                  ))}
                </ul>
                <div className="mt-8">
                  <div className="rounded-lg shadow-md">
                    <Button 
                      className="w-full flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary hover:bg-indigo-700"
                      onClick={scrollToWaitlist}
                    >
                      Join Waitlist
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
