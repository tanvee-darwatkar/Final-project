import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

const HeroSection = () => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Error",
        description: "Please enter your email address",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const response = await apiRequest('POST', '/api/waitlist', { email });
      
      if (response.ok) {
        toast({
          title: "Success!",
          description: "You've been added to our waitlist. We'll notify you when we launch.",
          variant: "default"
        });
        setEmail('');
      } else {
        const data = await response.json();
        toast({
          title: "Error",
          description: data.message || "Failed to join waitlist. Please try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="bg-gradient-to-b from-indigo-50 to-white pt-16 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
            <h1>
              <span className="block text-base font-semibold text-primary tracking-wide uppercase">Coming Soon</span>
              <span className="mt-1 block text-4xl tracking-tight font-extrabold sm:text-5xl xl:text-6xl">
                <span className="block text-gray-900">Advanced Keyword</span>
                <span className="block text-primary">Research Tool</span>
              </span>
            </h1>
            <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-xl lg:text-lg xl:text-xl">
              Discover high-value keywords for your content with our state-of-the-art research tool. Get comprehensive metrics, competitor insights, and actionable data to boost your SEO strategy.
            </p>
            <div className="mt-8 sm:max-w-lg sm:mx-auto sm:text-center lg:text-left lg:mx-0">
              <form className="mt-3 sm:flex" id="waitlist-form" onSubmit={handleSubmit}>
                <label htmlFor="email" className="sr-only">Email</label>
                <Input
                  type="email"
                  name="email"
                  id="email"
                  required
                  className="block w-full py-3 text-base rounded-md placeholder-gray-500 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:flex-1 border-gray-300"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isSubmitting}
                />
                <Button 
                  type="submit"
                  className="mt-3 w-full px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:flex-shrink-0 sm:inline-flex sm:items-center sm:w-auto"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Submitting...' : 'Join Waitlist'}
                </Button>
              </form>
              <p className="mt-3 text-sm text-gray-500">
                We'll notify you when we launch. No spam, ever.
              </p>
            </div>
          </div>
          <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
            <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
              <div className="relative block w-full bg-white rounded-lg overflow-hidden">
                <svg className="w-full" viewBox="0 0 600 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect width="600" height="400" fill="#F3F4F6" />
                  <path d="M200 150H400V250H200V150Z" fill="#4F46E5" fillOpacity="0.7" />
                  <path d="M150 100H450V300H150V100Z" stroke="#4F46E5" strokeWidth="4" strokeDasharray="8 8" />
                  <path d="M250 175H350V225H250V175Z" fill="white" />
                  <path d="M270 200H330" stroke="#4F46E5" strokeWidth="2" />
                  <path d="M270 190H330" stroke="#4F46E5" strokeWidth="2" />
                  <path d="M270 210H330" stroke="#4F46E5" strokeWidth="2" />
                </svg>
                <div className="absolute inset-0 w-full h-full flex items-center justify-center">
                  <svg className="h-20 w-20 text-primary opacity-75" fill="currentColor" viewBox="0 0 84 84">
                    <circle opacity="0.8" cx="42" cy="42" r="42" fill="white"></circle>
                    <path d="M55.5039 40.3359L37.1094 28.0729C35.7803 27.1869 34 28.1396 34 29.737V54.263C34 55.8604 35.7803 56.8131 37.1094 55.9271L55.5038 43.6641C56.6913 42.8725 56.6913 41.1275 55.5039 40.3359Z" fill="currentColor"></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
