import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

const CTASection = () => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Error",
        description: "Please enter your email address",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      console.log('Sending waitlist request with email:', email);
      const response = await apiRequest(
        'POST', 
        '/api/waitlist', 
        { email }
      );
      
      const data = await response.json();
      
      if (response.ok) {
        toast({
          title: "Success!",
          description: "You've been added to our waitlist. We'll notify you when we launch.",
          variant: "default"
        });
        setEmail('');
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to join waitlist. Please try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Waitlist error:', error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-16 bg-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex lg:items-center lg:justify-between">
          <div className="lg:max-w-xl lg:mr-8">
            <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
              <span className="block">Ready to supercharge your keyword research?</span>
            </h2>
            <p className="mt-3 text-lg leading-6 text-indigo-200">
              Be among the first to access our powerful keyword research platform. Sign up for the waitlist today and receive exclusive early access and special pricing.
            </p>
            <div className="mt-8 sm:flex">
              <form className="sm:flex" onSubmit={handleSubmit}>
                <label htmlFor="email-cta" className="sr-only">Email address</label>
                <Input
                  id="email-cta"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  className="w-full px-5 py-3 placeholder-gray-500 focus:ring-white focus:border-white sm:max-w-xs border-transparent rounded-md bg-white text-gray-900"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isSubmitting}
                />
                <div className="mt-3 rounded-md shadow sm:mt-0 sm:ml-3 sm:flex-shrink-0">
                  <Button
                    type="submit"
                    className="w-full flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-primary bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Submitting...' : 'Join Waitlist'}
                  </Button>
                </div>
              </form>
            </div>
          </div>
          <div className="mt-8 lg:mt-0">
            <div className="rounded-lg shadow-lg overflow-hidden">
              <svg className="w-full h-auto" viewBox="0 0 500 300" xmlns="http://www.w3.org/2000/svg">
                <rect width="500" height="300" fill="#F3F4F6" />
                <rect x="30" y="30" width="440" height="240" fill="#FFFFFF" stroke="#E5E7EB" strokeWidth="2" rx="4" />
                <rect x="50" y="50" width="180" height="20" fill="#4F46E5" opacity="0.2" rx="4" />
                <rect x="50" y="80" width="400" height="1" fill="#E5E7EB" />
                <rect x="50" y="100" width="400" height="40" fill="#F9FAFB" rx="4" />
                <rect x="70" y="115" width="100" height="10" fill="#4F46E5" opacity="0.3" rx="2" />
                <rect x="350" y="110" width="80" height="20" fill="#4F46E5" rx="4" />
                <rect x="50" y="150" width="400" height="1" fill="#E5E7EB" />
                <rect x="50" y="170" width="180" height="80" fill="#F3F4F6" rx="4" />
                <rect x="250" y="170" width="200" height="80" fill="#F3F4F6" rx="4" />
                <rect x="70" y="190" width="140" height="10" fill="#4F46E5" opacity="0.2" rx="2" />
                <rect x="70" y="210" width="100" height="10" fill="#4F46E5" opacity="0.1" rx="2" />
                <rect x="270" y="190" width="140" height="10" fill="#4F46E5" opacity="0.2" rx="2" />
                <rect x="270" y="210" width="100" height="10" fill="#4F46E5" opacity="0.1" rx="2" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
