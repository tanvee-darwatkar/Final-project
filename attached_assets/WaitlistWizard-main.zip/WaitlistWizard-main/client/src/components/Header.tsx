import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const Header = () => {
  const [mobileMenuVisible, setMobileMenuVisible] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuVisible(!mobileMenuVisible);
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <svg className="h-8 w-8 text-primary" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span className="ml-2 text-xl font-bold text-gray-900">KeywordInsight</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#features" className="text-base font-medium text-gray-700 hover:text-primary">Features</a>
            <a href="#how-it-works" className="text-base font-medium text-gray-700 hover:text-primary">How It Works</a>
            <a href="#pricing" className="text-base font-medium text-gray-700 hover:text-primary">Pricing</a>
            <Button 
              className="bg-primary text-white hover:bg-indigo-700 transition-colors"
              onClick={() => document.getElementById('waitlist-form')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Join Waitlist
            </Button>
          </nav>
          <div className="md:hidden">
            <button
              type="button"
              className="text-gray-500 hover:text-gray-700"
              onClick={toggleMobileMenu}
            >
              <i className="fas fa-bars text-xl"></i>
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuVisible && (
          <div className="md:hidden" id="mobile-menu">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <a 
                href="#features" 
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100"
                onClick={() => setMobileMenuVisible(false)}
              >
                Features
              </a>
              <a 
                href="#how-it-works" 
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100"
                onClick={() => setMobileMenuVisible(false)}
              >
                How It Works
              </a>
              <a 
                href="#pricing" 
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100"
                onClick={() => setMobileMenuVisible(false)}
              >
                Pricing
              </a>
              <Button 
                className="mt-2 w-full bg-primary text-white hover:bg-indigo-700 transition-colors"
                onClick={() => {
                  document.getElementById('waitlist-form')?.scrollIntoView({ behavior: 'smooth' });
                  setMobileMenuVisible(false);
                }}
              >
                Join Waitlist
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
