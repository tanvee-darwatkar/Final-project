const HowItWorksSection = () => {
  const steps = [
    {
      number: 1,
      title: 'Enter Your Seed Keyword',
      description: 'Start with a core topic or keyword that\'s relevant to your content. Our system will use this as a foundation for your research.'
    },
    {
      number: 2,
      title: 'Review Comprehensive Results',
      description: 'Get instant access to search volume, competition, trends, and CPC data. Our visual metrics make it easy to spot the best opportunities.'
    },
    {
      number: 3,
      title: 'Filter and Refine',
      description: 'Use our advanced filters to narrow down results based on your specific needs, such as minimum search volume or competition level.'
    },
    {
      number: 4,
      title: 'Export and Implement',
      description: 'Download your curated keyword list and integrate it directly into your content strategy. Track performance over time to optimize results.'
    }
  ];

  return (
    <section className="py-16 bg-white" id="how-it-works">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base font-semibold tracking-wide uppercase text-primary">How It Works</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Simple, Powerful Keyword Research
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Our intuitive process helps you find the best keywords in minutes.
          </p>
        </div>

        <div className="mt-20">
          <div className="lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="lg:col-span-5">
              <div className="relative mb-12 lg:mb-0">
                <div className="rounded-lg shadow-xl overflow-hidden">
                  <svg className="w-full object-cover" viewBox="0 0 600 400" xmlns="http://www.w3.org/2000/svg">
                    <rect width="600" height="400" fill="#F3F4F6" />
                    <rect x="50" y="50" width="500" height="300" fill="#FFFFFF" stroke="#E5E7EB" strokeWidth="2" />
                    <rect x="80" y="80" width="440" height="60" fill="#F9FAFB" stroke="#E5E7EB" strokeWidth="1" />
                    <rect x="100" y="100" width="300" height="20" fill="#4F46E5" opacity="0.2" rx="4" />
                    <rect x="80" y="160" width="440" height="60" fill="#F3F4F6" stroke="#E5E7EB" strokeWidth="1" />
                    <rect x="100" y="180" width="200" height="20" fill="#4F46E5" opacity="0.3" rx="4" />
                    <rect x="80" y="240" width="440" height="60" fill="#F9FAFB" stroke="#E5E7EB" strokeWidth="1" />
                    <rect x="100" y="260" width="250" height="20" fill="#4F46E5" opacity="0.2" rx="4" />
                  </svg>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7">
              <div className="space-y-12">
                {steps.map((step) => (
                  <div key={step.number} className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary text-white">
                        {step.number}
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">{step.title}</h3>
                      <p className="mt-2 text-base text-gray-500">
                        {step.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
