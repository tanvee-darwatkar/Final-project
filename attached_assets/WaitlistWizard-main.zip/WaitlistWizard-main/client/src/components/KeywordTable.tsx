import { useState } from 'react';
import { 
  Keyword 
} from '@/lib/types';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { FileDown, FileUp } from 'lucide-react';
import { exportToCSV, exportKeywordData } from '@/lib/csvExport';

interface KeywordTableProps {
  keywords: Keyword[];
  totalResults: number;
  currentKeyword: string;
}

const KeywordTable = ({ keywords, totalResults, currentKeyword }: KeywordTableProps) => {
  const [sortCriteria, setSortCriteria] = useState<string>('volume');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Sort keywords based on criteria
  const sortedKeywords = [...keywords].sort((a, b) => {
    switch (sortCriteria) {
      case 'volume':
        return b.searchVolume - a.searchVolume;
      case 'competition':
        const competitionOrder = { 'High': 3, 'Medium': 2, 'Low': 1 };
        return competitionOrder[b.competition as keyof typeof competitionOrder] - 
               competitionOrder[a.competition as keyof typeof competitionOrder];
      case 'trend':
        return b.trend - a.trend;
      case 'category':
        return a.category.localeCompare(b.category);
      case 'cpc':
        return b.cpc - a.cpc;
      default:
        return b.searchVolume - a.searchVolume;
    }
  });

  // Calculate pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentKeywords = sortedKeywords.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(sortedKeywords.length / itemsPerPage);

  // Handle sorting change
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortCriteria(e.target.value);
  };

  // Handle CSV export
  const handleExport = () => {
    exportKeywordData(sortedKeywords, currentKeyword);
  };

  // Calculate difficulty color
  const getDifficultyColor = (difficulty: number) => {
    if (difficulty >= 75) return 'bg-red-500';
    if (difficulty >= 50) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  // Render pagination buttons
  const renderPaginationButtons = () => {
    let buttons = [];
    
    // Previous button
    buttons.push(
      <a 
        key="prev" 
        onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
        className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 cursor-pointer"
      >
        <span className="sr-only">Previous</span>
        <i className="fas fa-chevron-left text-xs"></i>
      </a>
    );
    
    // First page
    buttons.push(
      <a 
        key={1}
        onClick={() => setCurrentPage(1)}
        className={`relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium ${
          currentPage === 1 ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-50'
        } cursor-pointer`}
      >
        1
      </a>
    );
    
    // Ellipsis if needed at start
    if (currentPage > 3) {
      buttons.push(
        <span key="start-ellipsis" className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">
          ...
        </span>
      );
    }
    
    // Pages around current page
    for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
      if (i <= totalPages && i > 1) {
        buttons.push(
          <a 
            key={i}
            onClick={() => setCurrentPage(i)}
            className={`relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium ${
              currentPage === i ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-50'
            } cursor-pointer`}
          >
            {i}
          </a>
        );
      }
    }
    
    // Ellipsis if needed at end
    if (currentPage < totalPages - 2 && totalPages > 3) {
      buttons.push(
        <span key="end-ellipsis" className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">
          ...
        </span>
      );
    }
    
    // Last page if not already included
    if (totalPages > 1) {
      buttons.push(
        <a 
          key={totalPages}
          onClick={() => setCurrentPage(totalPages)}
          className={`relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium ${
            currentPage === totalPages ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-50'
          } cursor-pointer`}
        >
          {totalPages}
        </a>
      );
    }
    
    // Next button
    buttons.push(
      <a 
        key="next" 
        onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
        className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 cursor-pointer"
      >
        <span className="sr-only">Next</span>
        <i className="fas fa-chevron-right text-xs"></i>
      </a>
    );
    
    return buttons;
  };

  return (
    <div className="px-6 py-5">
      <div className="flex items-center justify-between bg-gray-50 px-6 py-5 mb-4 rounded-t-lg">
        <h3 className="text-lg font-medium text-gray-900">
          Results for <span className="font-bold text-primary">{currentKeyword}</span>
        </h3>
        <div className="flex items-center">
          <Button 
            variant="outline" 
            onClick={handleExport}
            className="mr-4 text-gray-700 hover:text-gray-900 bg-white hover:bg-gray-50 flex items-center"
          >
            <FileDown className="mr-2 h-4 w-4" /> Export CSV
          </Button>
          <div className="relative">
            <select 
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
              value={sortCriteria}
              onChange={handleSortChange}
            >
              <option value="volume">Sort by Volume</option>
              <option value="competition">Sort by Competition</option>
              <option value="trend">Sort by Trend</option>
              <option value="cpc">Sort by CPC</option>
              <option value="category">Sort by Category</option>
            </select>
          </div>
        </div>
      </div>

      <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Keyword
              </TableHead>
              <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Volume
              </TableHead>
              <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Difficulty
              </TableHead>
              <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                CPC
              </TableHead>
              <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Trend
              </TableHead>
              <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="bg-white divide-y divide-gray-200">
            {currentKeywords.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{item.keyword}</div>
                </TableCell>
                <TableCell className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 font-mono">{item.searchVolume.toLocaleString()}</div>
                </TableCell>
                <TableCell className="px-6 py-4 whitespace-nowrap">
                  <div className="inline-flex items-center">
                    <div className="w-16 bg-gray-200 rounded-full h-2.5">
                      <div className={`${getDifficultyColor(item.difficulty)} h-2.5 rounded-full`} style={{ width: `${item.difficulty}%` }}></div>
                    </div>
                    <span className="ml-2 text-sm text-gray-900">{item.difficulty}</span>
                  </div>
                </TableCell>
                <TableCell className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 font-mono">${item.cpc.toFixed(2)}</div>
                </TableCell>
                <TableCell className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.trend >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    <i className={`fas fa-arrow-${item.trend >= 0 ? 'up' : 'down'} mr-1`}></i> {Math.abs(item.trend)}%
                  </span>
                </TableCell>
                <TableCell className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 py-1 inline-flex text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                    {item.category}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div className="text-sm text-gray-700">
          Showing <span className="font-medium">{Math.min(sortedKeywords.length, currentPage * itemsPerPage)}</span> of <span className="font-medium">{totalResults}</span> results
        </div>
        <div>
          <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
            {renderPaginationButtons()}
          </nav>
        </div>
      </div>
    </div>
  );
};

export default KeywordTable;
