const FeaturesSection = () => {
  const features = [
    {
      icon: 'fa-chart-bar',
      title: 'Advanced Metrics',
      description: 'Get detailed insights into search volume, competition, CPC, and trends for any keyword.'
    },
    {
      icon: 'fa-lightbulb',
      title: 'Smart Suggestions',
      description: 'Discover related keywords and long-tail variations to expand your content opportunities.'
    },
    {
      icon: 'fa-file-export',
      title: 'Export Capabilities',
      description: 'Download your keyword research data in CSV format for seamless integration with your workflow.'
    },
    {
      icon: 'fa-history',
      title: 'Historical Trends',
      description: 'Analyze keyword popularity over time to identify seasonal patterns and emerging opportunities.'
    },
    {
      icon: 'fa-filter',
      title: 'Advanced Filtering',
      description: 'Sort and filter keywords by multiple metrics to find the perfect match for your content strategy.'
    },
    {
      icon: 'fa-globe',
      title: 'Global Coverage',
      description: 'Research keywords across multiple languages and regions to optimize your international SEO strategy.'
    }
  ];

  return (
    <section className="py-16 bg-gray-50" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base font-semibold tracking-wide uppercase text-primary">Features</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Everything You Need for Keyword Research
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Our platform provides comprehensive keyword research tools to help you optimize your content strategy.
          </p>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <div key={index} className="relative">
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                  <i className={`fas ${feature.icon}`}></i>
                </div>
                <div className="ml-16">
                  <h3 className="text-lg font-medium text-gray-900">{feature.title}</h3>
                  <p className="mt-2 text-base text-gray-500">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
