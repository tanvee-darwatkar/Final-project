import { Keyword } from '@/lib/types';
import KeywordMetrics from './KeywordMetrics';
import VolumeChart from './VolumeChart';
import KeywordTable from './KeywordTable';
import CategoryPieChart from './CategoryPieChart';
import KeywordComparisonChart from './KeywordComparisonChart';

interface KeywordResultsProps {
  keywords: Keyword[];
  currentKeyword: string;
  isVisible: boolean;
}

const KeywordResults = ({ keywords, currentKeyword, isVisible }: KeywordResultsProps) => {
  if (!isVisible || keywords.length === 0) {
    return null;
  }

  // Use the first keyword for metrics and chart display
  const primaryKeyword = keywords[0];

  return (
    <div className="border-t border-gray-200">
      <div className="flex flex-col">
        {/* Metrics Overview */}
        <KeywordMetrics keyword={primaryKeyword} />
        
        {/* Charts Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <VolumeChart volumeTrend={primaryKeyword.volumeTrend} />
          <CategoryPieChart keywords={keywords} />
        </div>
        
        {/* Additional Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <KeywordComparisonChart keywords={keywords} metric="searchVolume" limit={5} />
          <KeywordComparisonChart keywords={keywords} metric="cpc" limit={5} />
        </div>
        
        {/* Keywords Table */}
        <KeywordTable 
          keywords={keywords} 
          totalResults={keywords.length} 
          currentKeyword={currentKeyword}
        />
      </div>
    </div>
  );
};

export default KeywordResults;
