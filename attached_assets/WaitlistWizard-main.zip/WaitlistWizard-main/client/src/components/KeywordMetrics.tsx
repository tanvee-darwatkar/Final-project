import { Card, CardContent } from '@/components/ui/card';
import { Keyword, KeywordMetric } from '@/lib/types';

interface KeywordMetricsProps {
  keyword: Keyword;
}

const KeywordMetrics = ({ keyword }: KeywordMetricsProps) => {
  const metrics: KeywordMetric[] = [
    {
      title: 'Monthly Search Volume',
      value: keyword.searchVolume.toLocaleString(),
      icon: 'fa-search',
      color: 'indigo'
    },
    {
      title: 'Trend',
      value: `${keyword.trend > 0 ? '+' : ''}${keyword.trend}%`,
      icon: 'fa-chart-line',
      color: 'emerald',
      secondaryInfo: {
        value: keyword.trend > 0 ? 'Increasing' : 'Decreasing',
        icon: keyword.trend > 0 ? 'fa-arrow-up' : 'fa-arrow-down',
        color: keyword.trend > 0 ? 'text-secondary' : 'text-red-500'
      }
    },
    {
      title: 'Competition',
      value: keyword.competition,
      icon: 'fa-trophy',
      color: 'amber',
      secondaryInfo: {
        value: '',
        icon: '',
        color: ''
      }
    },
    {
      title: 'CPC',
      value: `$${keyword.cpc.toFixed(2)}`,
      icon: 'fa-dollar-sign',
      color: 'red'
    }
  ];

  // Helper function to get the competition level indicator
  const getCompetitionIndicator = (competition: string) => {
    let indicators = [];
    let filledCount = 0;

    if (competition === 'High') filledCount = 3;
    else if (competition === 'Medium') filledCount = 2;
    else if (competition === 'Low') filledCount = 1;

    for (let i = 0; i < 3; i++) {
      indicators.push(
        <span 
          key={i} 
          className={`w-4 h-2 ${i < filledCount ? 'bg-amber-300' : 'bg-gray-200'} rounded-full ${i < 2 ? 'mr-1' : ''}`}
        />
      );
    }

    return indicators;
  };

  return (
    <div className="px-6 py-5 grid grid-cols-1 md:grid-cols-4 gap-4">
      {metrics.map((metric, index) => (
        <Card key={index} className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
          <CardContent className="p-0">
            <div className="flex items-center">
              <div className={`flex-shrink-0 rounded-md bg-${metric.color}-50 p-3`}>
                <i className={`fas ${metric.icon} text-${metric.color === 'indigo' ? 'primary' : metric.color === 'emerald' ? 'secondary' : metric.color}-500 text-xl`}></i>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">{metric.title}</dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">{metric.value}</div>
                    {metric.secondaryInfo && metric.title === 'Trend' && (
                      <div className={`ml-2 flex items-baseline text-sm font-semibold ${metric.secondaryInfo.color}`}>
                        <i className={`fas ${metric.secondaryInfo.icon}`}></i>
                        <span className="ml-1">{metric.secondaryInfo.value}</span>
                      </div>
                    )}
                    {metric.title === 'Competition' && (
                      <div className="ml-2 flex items-baseline">
                        {getCompetitionIndicator(keyword.competition)}
                      </div>
                    )}
                  </dd>
                </dl>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default KeywordMetrics;
