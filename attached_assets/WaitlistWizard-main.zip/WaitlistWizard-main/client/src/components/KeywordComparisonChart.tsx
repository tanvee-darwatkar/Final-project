import { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { Keyword } from '@/lib/types';

interface KeywordComparisonChartProps {
  keywords: Keyword[];
  metric: 'searchVolume' | 'cpc' | 'difficulty';
  limit?: number;
}

const metricColors = {
  searchVolume: '#4F46E5',
  cpc: '#F59E0B',
  difficulty: '#EF4444'
};

const metricLabels = {
  searchVolume: 'Search Volume',
  cpc: 'Cost Per Click (CPC)',
  difficulty: 'Difficulty'
};

const KeywordComparisonChart = ({ keywords, metric, limit = 10 }: KeywordComparisonChartProps) => {
  const chartData = useMemo(() => {
    // Sort by selected metric (descending) and take top N keywords
    return [...keywords]
      .sort((a, b) => b[metric] - a[metric])
      .slice(0, limit)
      .map(kw => ({
        name: kw.keyword.length > 15 ? kw.keyword.substring(0, 15) + '...' : kw.keyword,
        [metric]: kw[metric],
        fullName: kw.keyword
      }));
  }, [keywords, metric, limit]);

  const formatYAxisTick = (value: number): string => {
    if (metric === 'searchVolume') {
      if (value >= 1000000) {
        return `${(value / 1000000).toFixed(1)}M`;
      } else if (value >= 1000) {
        return `${(value / 1000).toFixed(0)}K`;
      }
      return value.toString();
    } else if (metric === 'cpc') {
      return `$${value.toFixed(2)}`;
    } else {
      return value.toString();
    }
  };

  const renderCustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="custom-tooltip" style={{ 
          backgroundColor: 'white', 
          padding: '10px',
          border: '1px solid #E5E7EB',
          borderRadius: '0.375rem',
          boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
        }}>
          <p className="label" style={{ margin: 0 }}><strong>{data.fullName}</strong></p>
          <p className="intro" style={{ margin: 0 }}>
            {metricLabels[metric]}: {
              metric === 'cpc' 
                ? `$${payload[0].value.toFixed(2)}` 
                : metric === 'searchVolume' 
                  ? payload[0].value.toLocaleString()
                  : payload[0].value
            }
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="px-6 py-5">
      <Card className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
        <CardContent className="p-0">
          <h4 className="text-base font-medium text-gray-900 mb-4">
            Top Keywords by {metricLabels[metric]}
          </h4>
          <div className="h-80 bg-gray-50 rounded-lg border border-gray-100">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                layout="vertical"
                margin={{ top: 20, right: 30, left: 80, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                <XAxis 
                  type="number" 
                  tickFormatter={(value) => formatYAxisTick(Number(value))}
                  tick={{ fontSize: 12, fill: '#6B7280' }}
                  axisLine={{ stroke: '#E5E7EB' }}
                  tickLine={false}
                />
                <YAxis 
                  type="category"
                  dataKey="name" 
                  tick={{ fontSize: 12, fill: '#6B7280' }}
                  axisLine={{ stroke: '#E5E7EB' }}
                  tickLine={false}
                />
                <Tooltip content={renderCustomTooltip} />
                <Bar 
                  dataKey={metric} 
                  fill={metricColors[metric]} 
                  background={{ fill: '#f3f4f6' }}
                  barSize={20}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default KeywordComparisonChart;