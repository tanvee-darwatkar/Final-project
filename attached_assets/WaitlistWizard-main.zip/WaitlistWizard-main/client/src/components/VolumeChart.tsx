import { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

interface VolumeChartProps {
  volumeTrend: number[];
}

const VolumeChart = ({ volumeTrend }: VolumeChartProps) => {
  const chartData = useMemo(() => {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    
    return volumeTrend.map((volume, index) => ({
      month: months[index % 12],
      volume
    }));
  }, [volumeTrend]);

  const formatYAxisTick = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      return `${(value / 1000).toFixed(0)}K`;
    }
    return value;
  };

  return (
    <div className="px-6 py-5">
      <Card className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
        <CardContent className="p-0">
          <h4 className="text-base font-medium text-gray-900 mb-4">Search Volume Trend (Last 12 Months)</h4>
          <div className="h-64 bg-gray-50 rounded-lg border border-gray-100">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis 
                  dataKey="month" 
                  tick={{ fontSize: 12, fill: '#6B7280' }}
                  axisLine={{ stroke: '#E5E7EB' }}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12, fill: '#6B7280' }}
                  axisLine={{ stroke: '#E5E7EB' }}
                  tickLine={false}
                  tickFormatter={formatYAxisTick}
                />
                <Tooltip 
                  formatter={(value: number) => [value.toLocaleString(), 'Search Volume']}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #E5E7EB',
                    borderRadius: '0.375rem',
                    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="volume"
                  stroke="#4F46E5"
                  strokeWidth={2}
                  fill="#4F46E5"
                  fillOpacity={0.2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VolumeChart;
