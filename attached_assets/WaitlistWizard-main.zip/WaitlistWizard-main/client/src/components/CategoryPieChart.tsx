import { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Keyword } from '@/lib/types';

interface CategoryPieChartProps {
  keywords: Keyword[];
}

const COLORS = ['#4F46E5', '#0EA5E9', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

const CategoryPieChart = ({ keywords }: CategoryPieChartProps) => {
  const categoryData = useMemo(() => {
    // Aggregate data by category
    const categoryMap = new Map<string, number>();
    
    keywords.forEach(keyword => {
      const currentCount = categoryMap.get(keyword.category) || 0;
      categoryMap.set(keyword.category, currentCount + 1);
    });
    
    // Convert to chart data format
    return Array.from(categoryMap.entries()).map(([name, value]) => ({
      name,
      value
    }));
  }, [keywords]);

  // Calculate total keywords
  const totalKeywords = keywords.length;

  return (
    <div className="px-6 py-5">
      <Card className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
        <CardContent className="p-0">
          <h4 className="text-base font-medium text-gray-900 mb-4">Category Distribution</h4>
          <div className="h-64 bg-gray-50 rounded-lg border border-gray-100">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: number) => [
                    `${value} keyword${value !== 1 ? 's' : ''} (${((value / totalKeywords) * 100).toFixed(0)}%)`, 
                    'Count'
                  ]}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #E5E7EB',
                    borderRadius: '0.375rem',
                    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CategoryPieChart;