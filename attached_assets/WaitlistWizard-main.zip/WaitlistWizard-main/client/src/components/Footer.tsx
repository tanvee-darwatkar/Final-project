const Footer = () => {
  const footerLinks = [
    {
      category: 'Product',
      links: [
        { name: 'Features', href: '#features' },
        { name: 'Pricing', href: '#pricing' },
        { name: 'API', href: '#' },
        { name: 'Integrations', href: '#' },
      ]
    },
    {
      category: 'Resources',
      links: [
        { name: 'Documentation', href: '#' },
        { name: 'Guides', href: '#' },
        { name: 'Blog', href: '#' },
        { name: 'Support', href: '#' },
      ]
    },
    {
      category: 'Company',
      links: [
        { name: 'About', href: '#' },
        { name: 'Careers', href: '#' },
        { name: 'Privacy', href: '#' },
        { name: 'Terms', href: '#' },
      ]
    },
    {
      category: 'Connect',
      links: [
        { name: 'Twitter', href: '#' },
        { name: 'LinkedIn', href: '#' },
        { name: 'Facebook', href: '#' },
        { name: 'Contact', href: '#' },
      ]
    }
  ];

  const socialLinks = [
    { name: 'Twitter', icon: 'fa-twitter', href: '#' },
    { name: 'Facebook', icon: 'fa-facebook', href: '#' },
    { name: 'Instagram', icon: 'fa-instagram', href: '#' },
    { name: 'LinkedIn', icon: 'fa-linkedin', href: '#' },
  ];

  return (
    <footer className="bg-white">
      <div className="max-w-7xl mx-auto py-12 px-4 overflow-hidden sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {footerLinks.map((category, index) => (
            <div key={index}>
              <h3 className="text-sm font-semibold text-gray-500 tracking-wider uppercase">{category.category}</h3>
              <ul className="mt-4 space-y-4">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a href={link.href} className="text-base text-gray-500 hover:text-gray-900">
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-8 border-t border-gray-200 pt-8 md:flex md:items-center md:justify-between">
          <div className="flex space-x-6 md:order-2">
            {socialLinks.map((social, index) => (
              <a key={index} href={social.href} className="text-gray-400 hover:text-gray-500">
                <span className="sr-only">{social.name}</span>
                <i className={`fab ${social.icon} text-xl`}></i>
              </a>
            ))}
          </div>
          <p className="mt-8 text-base text-gray-400 md:mt-0 md:order-1">
            &copy; 2023 KeywordInsight. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
