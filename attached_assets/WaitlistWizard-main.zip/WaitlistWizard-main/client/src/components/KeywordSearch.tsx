import { useState, FormEvent, KeyboardEvent, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, History, Trash2 } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface KeywordSearchProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const RECENT_SEARCHES_KEY = 'recentSearches';
const MAX_RECENT_SEARCHES = 5;

const KeywordSearch = ({ onSearch, isLoading }: KeywordSearchProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [showRecentSearches, setShowRecentSearches] = useState(false);
  
  // Load recent searches from localStorage on component mount
  useEffect(() => {
    const savedSearches = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (savedSearches) {
      setRecentSearches(JSON.parse(savedSearches));
    }
  }, []);
  
  const saveRecentSearch = (search: string) => {
    const updatedSearches = [
      search,
      ...recentSearches.filter(s => s !== search) // Remove duplicates
    ].slice(0, MAX_RECENT_SEARCHES); // Limit to max searches
    
    setRecentSearches(updatedSearches);
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updatedSearches));
  };
  
  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem(RECENT_SEARCHES_KEY);
    setShowRecentSearches(false);
  };
  
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery.trim());
      saveRecentSearch(searchQuery.trim());
      setShowRecentSearches(false);
    }
  };
  
  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (searchQuery.trim()) {
        onSearch(searchQuery.trim());
        saveRecentSearch(searchQuery.trim());
        setShowRecentSearches(false);
      }
    }
  };
  
  const handleInputFocus = () => {
    if (recentSearches.length > 0) {
      setShowRecentSearches(true);
    }
  };
  
  const handleRecentSearchClick = (search: string) => {
    setSearchQuery(search);
    onSearch(search);
    saveRecentSearch(search);
    setShowRecentSearches(false);
  };
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      setShowRecentSearches(false);
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="relative px-6 py-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Keyword Research Tool</h2>
      <p className="text-gray-600 mb-6">
        Enter a keyword to get search volume, competition, and other metrics
      </p>
      
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <Input
            type="text"
            className="block w-full pl-10 pr-20 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary focus:border-primary"
            placeholder="Enter a keyword (e.g. SEO tools, content marketing)"
            id="keyword-search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={handleInputFocus}
            disabled={isLoading}
          />
          <div className="absolute inset-y-0 right-0 flex items-center">
            <Button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-primary hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              disabled={isLoading}
            >
              {isLoading ? 'Searching...' : 'Search'}
            </Button>
          </div>
          
          {/* Recent searches dropdown */}
          {showRecentSearches && recentSearches.length > 0 && (
            <Card className="absolute z-10 w-full mt-1 bg-white shadow-lg rounded-md overflow-hidden">
              <div className="p-2 flex justify-between items-center border-b">
                <div className="flex items-center text-sm font-medium text-gray-500">
                  <History className="h-4 w-4 mr-1" /> Recent Searches
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={(e) => {
                    e.stopPropagation();
                    clearRecentSearches();
                  }}
                  className="h-6 text-red-500 hover:text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-3 w-3 mr-1" /> Clear
                </Button>
              </div>
              <ul className="py-1">
                {recentSearches.map((search, index) => (
                  <li 
                    key={index} 
                    className="px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRecentSearchClick(search);
                    }}
                  >
                    {search}
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      </form>
      
      {/* Suggested keywords section */}
      <div className="mt-4">
        <p className="text-sm text-gray-500 mb-2">Popular searches:</p>
        <div className="flex flex-wrap gap-2">
          {['seo', 'digital marketing', 'content marketing', 'social media', 'email marketing'].map(
            (keyword, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchQuery(keyword);
                  onSearch(keyword);
                  saveRecentSearch(keyword);
                }}
                className="bg-gray-50"
              >
                {keyword}
              </Button>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default KeywordSearch;
