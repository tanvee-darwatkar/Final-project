import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import KeywordSearch from './KeywordSearch';
import KeywordResults from './KeywordResults';
import { useKeywordSearch } from '@/hooks/useKeywordSearch';

const DemoSearchSection = () => {
  const [resultsVisible, setResultsVisible] = useState(false);
  const { isLoading, data: keywords, searchKeyword, currentKeyword } = useKeywordSearch();

  const handleSearch = (query: string) => {
    searchKeyword(query);
    setResultsVisible(true);
  };

  return (
    <section className="py-12 bg-white" id="demo">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base font-semibold text-primary tracking-wide uppercase">Try It Now</h2>
          <p className="mt-1 text-3xl font-extrabold text-gray-900 sm:text-4xl sm:tracking-tight">
            Experience the Power
          </p>
          <p className="max-w-xl mt-5 mx-auto text-xl text-gray-500">
            Get a sneak peek at our keyword research capabilities
          </p>
        </div>

        <div className="mt-12">
          <div className="max-w-4xl mx-auto">
            <Card className="bg-white shadow-lg rounded-lg overflow-hidden">
              <CardContent className="px-6 py-8">
                <KeywordSearch 
                  onSearch={handleSearch}
                  isLoading={isLoading}
                />
              </CardContent>

              <KeywordResults 
                keywords={keywords || []}
                currentKeyword={currentKeyword}
                isVisible={resultsVisible && !isLoading && Boolean(keywords?.length)}
              />
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DemoSearchSection;
