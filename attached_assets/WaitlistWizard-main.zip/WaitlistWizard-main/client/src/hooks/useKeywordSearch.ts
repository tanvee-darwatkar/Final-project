import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { Keyword, KeywordSearchResponse } from '../lib/types';

interface UseKeywordSearchResult {
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  data: Keyword[] | undefined;
  searchKeyword: (query: string) => void;
  currentKeyword: string;
}

export function useKeywordSearch(): UseKeywordSearchResult {
  const [currentKeyword, setCurrentKeyword] = useState<string>('');

  const {
    isLoading,
    isError,
    error,
    data: responseData,
    refetch
  } = useQuery<KeywordSearchResponse>({
    queryKey: ['/api/keywords', currentKeyword],
    queryFn: async () => {
      if (!currentKeyword) return { keywords: [], totalResults: 0 };
      
      const response = await apiRequest('GET', `/api/keywords?q=${encodeURIComponent(currentKeyword)}`, undefined);
      const data = await response.json();
      console.log('Search response:', data);
      return data;
    },
    enabled: Boolean(currentKeyword),
  });

  const searchKeyword = (query: string) => {
    setCurrentKeyword(query);
    if (query) {
      refetch();
    }
  };

  return {
    isLoading,
    isError,
    error: error as Error | null,
    data: responseData?.keywords,
    searchKeyword,
    currentKeyword,
  };
}
