import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import KeywordSearch from '@/components/KeywordSearch';
import KeywordResults from '@/components/KeywordResults';
import { useKeywordSearch } from '@/hooks/useKeywordSearch';

const Dashboard = () => {
  const [resultsVisible, setResultsVisible] = useState(false);
  const { isLoading, data: keywords, searchKeyword, currentKeyword } = useKeywordSearch();

  const handleSearch = (query: string) => {
    searchKeyword(query);
    setResultsVisible(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="sticky top-0 z-50 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <svg className="h-8 w-8 text-primary" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
                </svg>
                <span className="ml-2 text-xl font-bold text-gray-900">KeywordInsight</span>
              </Link>
            </div>
            <Button variant="outline" asChild>
              <Link href="/">Back to Home</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-extrabold text-gray-900">Keyword Research Dashboard</h1>
            <p className="mt-4 text-lg text-gray-600">Search for keywords and analyze detailed metrics</p>
          </div>

          <div className="bg-white shadow-lg rounded-lg overflow-hidden mb-8">
            <div className="px-6 py-8">
              <KeywordSearch 
                onSearch={handleSearch}
                isLoading={isLoading}
              />
            </div>

            <KeywordResults 
              keywords={keywords || []}
              currentKeyword={currentKeyword}
              isVisible={resultsVisible && !isLoading && Boolean(keywords?.length)}
            />
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500">
            &copy; 2023 KeywordInsight. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
