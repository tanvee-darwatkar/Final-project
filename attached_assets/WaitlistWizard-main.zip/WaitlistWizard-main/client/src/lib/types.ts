export interface Keyword {
  id: number;
  keyword: string;
  searchVolume: number;
  competition: string;
  cpc: number;
  trend: number;
  difficulty: number;
  volumeTrend: number[];
  category: string;
  createdAt: Date;
}

export interface KeywordSearchResponse {
  keywords: Keyword[];
  totalResults: number;
}

export interface KeywordDetailResponse {
  keyword: Keyword;
}

export interface WaitlistFormData {
  email: string;
}

export interface WaitlistResponse {
  message: string;
  id: number;
}

export interface KeywordMetric {
  title: string;
  value: string | number;
  icon: string;
  color: string;
  secondaryInfo?: {
    value: string;
    icon: string;
    color: string;
  };
}
