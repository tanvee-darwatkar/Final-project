import { Keyword } from './types';

/**
 * Exports keywords data to a CSV file
 * @param keywords Array of keyword objects to export
 * @param filename Name of the file to download
 */
export const exportToCSV = (keywords: Keyword[], filename = 'keyword-data.csv'): void => {
  if (!keywords || keywords.length === 0) {
    console.error('No data to export');
    return;
  }

  // Define CSV headers
  const headers = [
    'Keyword',
    'Search Volume',
    'Competition',
    'CPC ($)',
    'Trend (%)',
    'Difficulty',
    'Category'
  ];

  // Convert keyword objects to CSV rows
  const rows = keywords.map(keyword => [
    `"${keyword.keyword}"`, // Quote the keyword to handle commas
    keyword.searchVolume.toString(),
    `"${keyword.competition}"`,
    keyword.cpc.toFixed(2),
    keyword.trend > 0 ? `+${keyword.trend}` : keyword.trend.toString(),
    keyword.difficulty.toString(),
    `"${keyword.category}"`
  ]);

  // Combine headers and rows
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');

  // Create a blob from the CSV content
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  // Create a link to download the file
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  // Add link to document, click it, and remove it
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

/**
 * Formats a date object to YYYY-MM-DD format
 * @param date Date object to format
 * @returns Formatted date string
 */
const formatDate = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

/**
 * Exports keywords data to a CSV file with a timestamp in the filename
 * @param keywords Array of keyword objects to export
 * @param searchTerm The search term used to generate these results
 */
export const exportKeywordData = (keywords: Keyword[], searchTerm: string): void => {
  if (!keywords || keywords.length === 0) return;
  
  const today = new Date();
  const formattedDate = formatDate(today);
  const sanitizedSearchTerm = searchTerm.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const filename = `keyword-data_${sanitizedSearchTerm}_${formattedDate}.csv`;
  
  exportToCSV(keywords, filename);
};
