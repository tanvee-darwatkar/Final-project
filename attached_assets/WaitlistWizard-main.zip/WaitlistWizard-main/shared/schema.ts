import { pgTable, text, serial, integer, boolean, jsonb, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for the waitlist
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  isWaitlist: boolean("is_waitlist").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users)
  .pick({
    username: true,
    password: true,
    email: true,
    isWaitlist: true,
  });

// Keywords schema
export const keywords = pgTable("keywords", {
  id: serial("id").primaryKey(),
  keyword: text("keyword").notNull().unique(),
  searchVolume: integer("search_volume").notNull(),
  competition: text("competition").notNull(),
  cpc: real("cpc").notNull(),
  trend: real("trend").notNull(),
  difficulty: integer("difficulty").notNull(),
  volumeTrend: jsonb("volume_trend").notNull(), // Array of monthly volumes for the chart
  category: text("category").notNull(), // Category for grouping and pie charts
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertKeywordSchema = createInsertSchema(keywords)
  .pick({
    keyword: true,
    searchVolume: true,
    competition: true,
    cpc: true,
    trend: true,
    difficulty: true,
    volumeTrend: true,
    category: true,
  });

// Search history schema
export const searchHistory = pgTable("search_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  keyword: text("keyword").notNull(),
  searchedAt: timestamp("searched_at").defaultNow().notNull(),
});

export const insertSearchHistorySchema = createInsertSchema(searchHistory)
  .pick({
    userId: true, 
    keyword: true,
  });

// Waitlist schema
export const waitlist = pgTable("waitlist", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertWaitlistSchema = createInsertSchema(waitlist)
  .pick({
    email: true,
  });

// Types for the schemas
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertKeyword = z.infer<typeof insertKeywordSchema>;
export type Keyword = typeof keywords.$inferSelect;

export type InsertSearchHistory = z.infer<typeof insertSearchHistorySchema>;
export type SearchHistory = typeof searchHistory.$inferSelect;

export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
export type Waitlist = typeof waitlist.$inferSelect;
