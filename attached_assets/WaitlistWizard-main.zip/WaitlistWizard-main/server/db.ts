import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '../shared/schema';
import { log } from './vite';

// Create postgres connection
const connectionString = process.env.DATABASE_URL as string;
const client = postgres(connectionString);

// Initialize drizzle with the client and schema
export const db = drizzle(client, { schema });

// Log database connection
log('Database connection established', 'database');