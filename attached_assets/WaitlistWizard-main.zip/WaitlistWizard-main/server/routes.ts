import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistSchema, insertUserSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the keyword research tool
  const apiRouter = app.use("/api", (req, res, next) => {
    next();
  });
  
  // Route to search for keywords
  app.get("/api/keywords", async (req, res) => {
    try {
      const query = req.query.q as string;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }

      const keywords = await storage.getKeywords(query);
      // Return in the format expected by the frontend
      return res.json({ 
        keywords: keywords,
        totalResults: keywords.length
      });
    } catch (error) {
      console.error("Error searching keywords:", error);
      return res.status(500).json({ message: "Failed to search keywords" });
    }
  });

  // Route to get a specific keyword
  app.get("/api/keywords/:keyword", async (req, res) => {
    try {
      const keywordName = req.params.keyword;
      
      if (!keywordName) {
        return res.status(400).json({ message: "Keyword is required" });
      }

      const keyword = await storage.getKeywordByName(keywordName);
      
      if (!keyword) {
        return res.status(404).json({ message: "Keyword not found" });
      }
      
      return res.json(keyword);
    } catch (error) {
      console.error("Error fetching keyword:", error);
      return res.status(500).json({ message: "Failed to fetch keyword details" });
    }
  });

  // Route to add to waitlist
  app.post("/api/waitlist", async (req, res) => {
    try {
      const data = insertWaitlistSchema.parse(req.body);
      
      // Check if email already exists in waitlist
      const existingEntry = await storage.getWaitlistByEmail(data.email);
      
      if (existingEntry) {
        return res.status(409).json({ message: "Email already registered for waitlist" });
      }
      
      const waitlistEntry = await storage.addToWaitlist(data);
      return res.status(201).json({ 
        message: "Successfully added to waitlist",
        id: waitlistEntry.id
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Error adding to waitlist:", error);
      return res.status(500).json({ message: "Failed to add to waitlist" });
    }
  });

  // Route to register a user
  app.post("/api/users", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUserByUsername = await storage.getUserByUsername(data.username);
      if (existingUserByUsername) {
        return res.status(409).json({ message: "Username already taken" });
      }
      
      const existingUserByEmail = await storage.getUserByEmail(data.email);
      if (existingUserByEmail) {
        return res.status(409).json({ message: "Email already registered" });
      }
      
      const user = await storage.createUser(data);
      return res.status(201).json({
        id: user.id,
        username: user.username,
        email: user.email,
        isWaitlist: user.isWaitlist
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Error registering user:", error);
      return res.status(500).json({ message: "Failed to register user" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
