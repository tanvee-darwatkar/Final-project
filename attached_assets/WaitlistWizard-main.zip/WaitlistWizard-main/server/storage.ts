import { 
  User, InsertUser, 
  Keyword, InsertKeyword, 
  SearchHistory, InsertSearchHistory,
  Waitlist, InsertWaitlist,
  users, keywords, searchHistory, waitlist
} from "@shared/schema";
import { db } from "./db";
import { eq, like, and, desc, not } from "drizzle-orm";

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Keyword operations
  getKeywordByName(keyword: string): Promise<Keyword | undefined>;
  getKeywords(query: string): Promise<Keyword[]>;
  createKeyword(keyword: InsertKeyword): Promise<Keyword>;
  
  // Search history operations
  createSearchHistory(searchHistory: InsertSearchHistory): Promise<SearchHistory>;
  getSearchHistoryByUserId(userId: number): Promise<SearchHistory[]>;
  
  // Waitlist operations
  addToWaitlist(waitlist: InsertWaitlist): Promise<Waitlist>;
  getWaitlistByEmail(email: string): Promise<Waitlist | undefined>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }
  
  // Keyword methods
  async getKeywordByName(keyword: string): Promise<Keyword | undefined> {
    const result = await db.select()
      .from(keywords)
      .where(eq(keywords.keyword, keyword))
      .limit(1);
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getKeywords(query: string): Promise<Keyword[]> {
    if (!query) return [];
    
    console.log(`Searching for keywords matching: "${query}"`);
    
    try {
      // First try an exact match on keyword
      const exactMatches = await db.select()
        .from(keywords)
        .where(eq(keywords.keyword, query))
        .limit(1);
      
      // If we find an exact match, prioritize it
      if (exactMatches.length > 0) {
        console.log(`Found exact match for "${query}"`);
        
        // Get related keywords based on the exact match's category
        const category = exactMatches[0].category;
        const relatedKeywords = await db.select()
          .from(keywords)
          .where(
            and(
              eq(keywords.category, category),
              not(eq(keywords.keyword, query))
            )
          )
          .orderBy(desc(keywords.searchVolume))
          .limit(19);
        
        // Combine the exact match with related keywords
        return [...exactMatches, ...relatedKeywords];
      }
      
      // If no exact match, do a LIKE search
      const likeMatches = await db.select()
        .from(keywords)
        .where(like(keywords.keyword, `%${query}%`))
        .orderBy(desc(keywords.searchVolume))
        .limit(20);
      
      console.log(`Found ${likeMatches.length} keywords matching "${query}"`);
      return likeMatches;
    } catch (error) {
      console.error('Error searching keywords:', error);
      return [];
    }
  }
  
  async createKeyword(insertKeyword: InsertKeyword): Promise<Keyword> {
    const result = await db.insert(keywords).values(insertKeyword).returning();
    return result[0];
  }
  
  // Search history methods
  async createSearchHistory(insertSearchHistory: InsertSearchHistory): Promise<SearchHistory> {
    const result = await db.insert(searchHistory).values(insertSearchHistory).returning();
    return result[0];
  }
  
  async getSearchHistoryByUserId(userId: number): Promise<SearchHistory[]> {
    return await db.select()
      .from(searchHistory)
      .where(eq(searchHistory.userId, userId))
      .orderBy(desc(searchHistory.searchedAt));
  }
  
  // Waitlist methods
  async addToWaitlist(insertWaitlist: InsertWaitlist): Promise<Waitlist> {
    const result = await db.insert(waitlist).values(insertWaitlist).returning();
    return result[0];
  }
  
  async getWaitlistByEmail(email: string): Promise<Waitlist | undefined> {
    const result = await db.select()
      .from(waitlist)
      .where(eq(waitlist.email, email))
      .limit(1);
    return result.length > 0 ? result[0] : undefined;
  }
  
  // Initialize with sample keywords data
  async initializeKeywords() {
    const sampleKeywords: InsertKeyword[] = [
      {
        keyword: "content marketing",
        searchVolume: 73400,
        competition: "Medium",
        cpc: 4.25,
        trend: 12,
        difficulty: 60,
        category: "Marketing",
        volumeTrend: [
          60000, 62000, 61000, 63000, 59000, 58000, 62000, 68000, 70000, 72000, 73000, 73400
        ],
      },
      {
        keyword: "content marketing strategy",
        searchVolume: 22200,
        competition: "High",
        cpc: 5.70,
        trend: 8,
        difficulty: 85,
        category: "Marketing",
        volumeTrend: [
          18000, 19000, 19500, 20000, 20500, 21000, 21200, 21500, 21800, 22000, 22100, 22200
        ],
      },
      {
        keyword: "b2b content marketing",
        searchVolume: 12100,
        competition: "Medium",
        cpc: 4.20,
        trend: 12,
        difficulty: 65,
        category: "Marketing",
        volumeTrend: [
          10000, 10200, 10500, 10800, 11000, 11200, 11400, 11600, 11800, 12000, 12050, 12100
        ],
      },
      {
        keyword: "content marketing examples",
        searchVolume: 9900,
        competition: "Low",
        cpc: 3.80,
        trend: 5,
        difficulty: 45,
        category: "Marketing",
        volumeTrend: [
          9000, 9100, 9200, 9300, 9400, 9500, 9600, 9700, 9800, 9850, 9900, 9900
        ],
      },
      {
        keyword: "content marketing tools",
        searchVolume: 8100,
        competition: "Medium",
        cpc: 3.25,
        trend: -2,
        difficulty: 68,
        category: "Marketing",
        volumeTrend: [
          8300, 8350, 8400, 8350, 8300, 8250, 8200, 8150, 8100, 8100, 8100, 8100
        ],
      },
      {
        keyword: "content marketing agency",
        searchVolume: 5400,
        competition: "High",
        cpc: 7.50,
        trend: 10,
        difficulty: 82,
        category: "Marketing",
        volumeTrend: [
          4800, 4900, 5000, 5050, 5100, 5150, 5200, 5250, 5300, 5350, 5380, 5400
        ],
      },
      {
        keyword: "seo",
        searchVolume: 550000,
        competition: "High",
        cpc: 9.30,
        trend: 5,
        difficulty: 92,
        category: "SEO",
        volumeTrend: [
          510000, 515000, 520000, 525000, 530000, 535000, 540000, 545000, 546000, 547000, 548000, 550000
        ],
      },
      {
        keyword: "seo tools",
        searchVolume: 40500,
        competition: "High",
        cpc: 8.90,
        trend: 7,
        difficulty: 88,
        category: "SEO",
        volumeTrend: [
          37000, 37500, 38000, 38500, 39000, 39500, 40000, 40100, 40200, 40300, 40400, 40500
        ],
      },
      {
        keyword: "seo audit",
        searchVolume: 27100,
        competition: "Medium",
        cpc: 6.70,
        trend: 4,
        difficulty: 75,
        category: "SEO",
        volumeTrend: [
          25000, 25300, 25600, 25900, 26200, 26500, 26700, 26800, 26900, 27000, 27050, 27100
        ],
      },
      {
        keyword: "seo optimization",
        searchVolume: 15800,
        competition: "Medium",
        cpc: 5.80,
        trend: 6,
        difficulty: 72,
        category: "SEO",
        volumeTrend: [
          14500, 14700, 14900, 15100, 15300, 15400, 15500, 15600, 15700, 15750, 15800, 15800
        ],
      },
      {
        keyword: "social media marketing",
        searchVolume: 165000,
        competition: "High",
        cpc: 7.20,
        trend: 15,
        difficulty: 78,
        category: "Social Media",
        volumeTrend: [
          140000, 142000, 145000, 148000, 150000, 152000, 155000, 158000, 160000, 162000, 164000, 165000
        ],
      },
      {
        keyword: "facebook ads",
        searchVolume: 110000,
        competition: "High",
        cpc: 8.10,
        trend: 8,
        difficulty: 80,
        category: "Social Media",
        volumeTrend: [
          98000, 100000, 102000, 104000, 105000, 106000, 107000, 108000, 108500, 109000, 109500, 110000
        ],
      },
      {
        keyword: "instagram marketing",
        searchVolume: 74500,
        competition: "Medium",
        cpc: 5.40,
        trend: 18,
        difficulty: 67,
        category: "Social Media",
        volumeTrend: [
          60000, 62000, 64000, 66000, 68000, 69000, 70000, 71000, 72000, 73000, 74000, 74500
        ],
      },
      {
        keyword: "email marketing",
        searchVolume: 135000,
        competition: "Medium",
        cpc: 6.50,
        trend: 4,
        difficulty: 70,
        category: "Email",
        volumeTrend: [
          128000, 129000, 130000, 131000, 132000, 132500, 133000, 133500, 134000, 134500, 134800, 135000
        ],
      },
      {
        keyword: "email campaigns",
        searchVolume: 45600,
        competition: "Medium",
        cpc: 4.80,
        trend: 6,
        difficulty: 65,
        category: "Email",
        volumeTrend: [
          42000, 42500, 43000, 43500, 44000, 44300, 44600, 44900, 45200, 45400, 45500, 45600
        ],
      }
    ];
    
    // Check if there are already keywords
    const count = await db.select({ count: keywords.id }).from(keywords);
    if (count.length === 0 || count[0].count === 0) {
      for (const keyword of sampleKeywords) {
        await this.createKeyword(keyword);
      }
    }
  }
}

// Initialize the database storage
export const storage = new DatabaseStorage();

// Seed the database with initial data
(async () => {
  try {
    await (storage as DatabaseStorage).initializeKeywords();
    console.log('Database initialized with sample keywords');
  } catch (error) {
    console.error('Error initializing database:', error);
  }
})();
